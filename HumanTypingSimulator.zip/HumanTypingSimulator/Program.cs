﻿using System;
using System.IO;
using System.Threading;
using WindowsInput;
using WindowsInput.Native;
class Program
{
    static void Main(string[] args)
    {
        try
        {
            // File path to your text file
            string filePath = "copy.txt"; // Ensure this path is correct and the file is accessible

            // Read text from the file
            string[] textToTypes = File.ReadAllLines(filePath);
            int typingDelay = 100;
            foreach (var textToType in textToTypes)
            {
                var sim = new InputSimulator();
                // Delay between keystrokes in milliseconds
                int startupDelay = 1000; // Initial delay before typing starts in milliseconds

                // Wait for a specified time to allow user to switch to the target application
                Console.WriteLine($"You have {startupDelay / 1000} seconds to focus on the target application...");
                Thread.Sleep(startupDelay);

                // Start typing the text
                sim.Keyboard.KeyPress(VirtualKeyCode.HOME);
                foreach (char c in textToType)
                {
                    try
                    {
                    sim.Keyboard.TextEntry(c);
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine($"An error occurred: {ex.Message}");
                    }
                    //Thread.Sleep(typingDelay); // Simulate a delay between keystrokes
                }
                sim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
                // Add a slight delay to ensure the last characters are processed
                //Thread.Sleep(typingDelay);
            }
            Thread.Sleep(typingDelay);
           
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
         Console.WriteLine("Typing simulation complete.");
    }
}
