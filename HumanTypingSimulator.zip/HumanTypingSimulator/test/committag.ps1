# Write-Host 'Changes are going to be saved'

# # Add and commit changes
# git add . 
# git commit -m "Generated Pipeline code has been committed"

# # Set git config
# git config --global user.name "Application.Devops"
# git config --global user.email "Application.Devops@royalmail.com"

# # Set the remote URL with a Personal Access Token
# $remoteUrl= "https://royalmailgroup:avz42kyuwxtzpqrx5phe7gxakc6pdwfpi4fck3lh2hleqlk5ia6a@dev.azure.com/royalmailgroup/EBUSINESS-DDS-Azure/_git/rmg.ebiz.dsp.devops"
# git remote set-url origin $remoteUrl

# # Tag the commit
# $tagName = "1.1.7" # Change this to your desired tag
# git tag -a $tagName -m "Release $tagName"

# # Push the tag to the remote
# git push origin $tagName



git clone https://royalmailgroup@dev.azure.com/royalmailgroup/EBUSINESS-DDS-Azure/_git/rmg.ebiz.dsp.devops
cd rmg.ebiz.dsp.devops

git config --global user.name "Application.Devops"
git config --global user.email "Application.Devops@royalmail.com"

# Correct variable assignment
$remoteUrl="https://royalmailgroup:avz42kyuwxtzpqrx5phe7gxakc6pdwfpi4fck3lh2hleqlk5ia6a@dev.azure.com/royalmailgroup/EBUSINESS-DDS-Azure/_git/rmg.ebiz.dsp.devops"
git remote set-url origin "$remoteUrl"
git tag -a "1.1.8" -m "Release $tagName"
git push origin "1.1.8"
