# Load the WindowsInput DLL
Add-Type -Path "WindowsInput.dll"

function Simulate-Typing {
    param (
        [int]$typingDelay = 100,
        [int]$startupDelay = 2000
    )
    
    try {
        # Read text from the clipboard
        $textToType = Get-Clipboard

        # Create an instance of InputSimulator
        $sim = New-Object WindowsInput.InputSimulator

        # Wait for a specified time to allow user to switch to the target application
        Write-Host "You have $(($startupDelay / 1000)) seconds to focus on the target application..."
        Start-Sleep -Milliseconds $startupDelay
        $lines = $textToType -split "`n"
        # Start typing the text
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            #$sim.Keyboard.KeyPress([WindowsInput.Native.VirtualKeyCode]::HOME)
            foreach ($c in $line.ToCharArray()) {
                $sim.Keyboard.TextEntry($c)
            }
        
            # Only press RETURN if it's not the last line
            if ($i -lt $lines.Count - 1) {
                $sim.Keyboard.KeyPress([WindowsInput.Native.VirtualKeyCode]::RETURN)
            }
        }
        

        # Add a slight delay to ensure the last characters are processed
        #Start-Sleep -Milliseconds $typingDelay

        Write-Host "Typing simulation complete."
    }
    catch {
        Write-Host "An error occurred: $($_.Exception.Message)"
    }
}

# Example usage
Simulate-Typing
