Add-Type -AssemblyName System.Windows.Forms



# Read text from the file
$textToType =  Get-Clipboard

$typingDelay = 100  # Delay between keystrokes in milliseconds
$startupDelay = 2000  # Initial delay before typing starts in milliseconds

# Wait for a specified time to allow the user to switch to the target application
Write-Host "You have $(($startupDelay / 1000)) seconds to focus on the target application..."
Start-Sleep -Milliseconds $startupDelay

# Function to send keystrokes
function Send-Keys {
    param (
        [string]$text
    )
    $lines = $text -split "`n"  # Split the text into lines
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]
        foreach ($c in $line.ToCharArray()) {
            [System.Windows.Forms.SendKeys]::SendWait($c)
            Start-Sleep -Milliseconds $typingDelay  # Add delay between keystrokes
        }

        # Only press RETURN if it's not the last line
        if ($i -lt $lines.Count - 1) {
            [System.Windows.Forms.SendKeys]::SendWait("{RETURN}")
        }
    }
}

# Start typing the text
Send-Keys $textToType

Write-Host "Typing simulation complete."
